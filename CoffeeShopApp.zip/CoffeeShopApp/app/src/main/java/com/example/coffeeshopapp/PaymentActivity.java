package com.example.coffeeshopapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class PaymentActivity extends AppCompatActivity {

    TextView totalText;
    Button payNowBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        totalText = findViewById(R.id.totalText);
        payNowBtn = findViewById(R.id.payNowBtn);

        int total = getIntent().getIntExtra("TOTAL_PRICE",0);

        totalText.setText("Total Amount: Rs " + total);

        payNowBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(PaymentActivity.this,
                        "Payment Successful ☕",
                        Toast.LENGTH_LONG).show();

                Intent intent = new Intent(PaymentActivity.this, ThanksActivity.class);
                startActivity(intent);
            }
        });
    }
}