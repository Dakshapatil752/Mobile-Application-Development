package com.example.coffeeshopapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity {

    CheckBox latte, cappuccino, espresso, americano, mocha, caramel;
    Button payBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        latte = findViewById(R.id.latte);
        cappuccino = findViewById(R.id.cappuccino);
        espresso = findViewById(R.id.espresso);
        americano = findViewById(R.id.americano);
        mocha = findViewById(R.id.mocha);
        caramel = findViewById(R.id.caramel);

        payBtn = findViewById(R.id.payBtn);

        payBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                int total = 0;

                if(latte.isChecked())
                    total += 80;

                if(cappuccino.isChecked())
                    total += 75;

                if(espresso.isChecked())
                    total += 60;

                if(americano.isChecked())
                    total += 90;

                if(mocha.isChecked())
                    total += 95;

                if(caramel.isChecked())
                    total += 100;

                Intent intent = new Intent(MenuActivity.this, PaymentActivity.class);
                intent.putExtra("TOTAL_PRICE", total);
                startActivity(intent);
            }
        });
    }
}