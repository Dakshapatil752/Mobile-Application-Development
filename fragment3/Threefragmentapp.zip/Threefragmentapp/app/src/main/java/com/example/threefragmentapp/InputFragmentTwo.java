package com.example.threefragmentapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.fragment.app.Fragment;

public class InputFragmentTwo extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_input_two, container, false);

        EditText et = view.findViewById(R.id.etInput2);
        Button btn = view.findViewById(R.id.btnSend2);

        btn.setOnClickListener(v -> {
            int value = Integer.parseInt(et.getText().toString());
            ((MainActivity) getActivity()).setSecondValue(value);
        });

        return view;
    }
}
