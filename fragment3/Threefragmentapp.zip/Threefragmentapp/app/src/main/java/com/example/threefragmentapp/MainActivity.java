package com.example.threefragmentapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    int num1, num2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (savedInstanceState == null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.container1, new InputFragmentOne())
                    .replace(R.id.container2, new InputFragmentTwo())
                    .replace(R.id.container3, new OutputFragment())
                    .commit();
        }
    }

    // Receive input from Fragment 1
    public void setFirstValue(int value) {
        num1 = value;
        updateResult();
    }

    // Receive input from Fragment 2
    public void setSecondValue(int value) {
        num2 = value;
        updateResult();
    }

    private void updateResult() {
        int sum = num1 + num2;

        OutputFragment fragment = (OutputFragment)
                getSupportFragmentManager().findFragmentById(R.id.container3);

        if (fragment != null) {
            fragment.showResult(sum);
        }
    }
}
