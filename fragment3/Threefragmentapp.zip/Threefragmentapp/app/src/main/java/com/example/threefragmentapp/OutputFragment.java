package com.example.threefragmentapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.os.Bundle;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

public class OutputFragment extends Fragment {

    TextView tvResult;

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_output, container, false);
        tvResult = view.findViewById(R.id.tvResult);
        return view;
    }

    public void showResult(int result) {
        tvResult.setText("Result: " + result);
    }
}
