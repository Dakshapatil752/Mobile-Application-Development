package com.example.musiccalculatorapp;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    MediaPlayer mediaPlayer;
    Button btnPlay, btnPause;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnPlay = findViewById(R.id.btnPlay);
        btnPause = findViewById(R.id.btnPause);

        mediaPlayer = MediaPlayer.create(this, R.raw.music);

        if (mediaPlayer == null) {
            Toast.makeText(this, "MediaPlayer failed to load music", Toast.LENGTH_LONG).show();
            return;
        }

        btnPlay.setOnClickListener(v -> {
            Toast.makeText(this, "Play clicked", Toast.LENGTH_SHORT).show();
            Log.d("MUSIC", "Play pressed");
            mediaPlayer.start();
        });

        btnPause.setOnClickListener(v -> {
            mediaPlayer.pause();
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
    }
}
