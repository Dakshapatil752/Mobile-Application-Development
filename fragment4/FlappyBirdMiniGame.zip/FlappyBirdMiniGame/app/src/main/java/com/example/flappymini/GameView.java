package com.example.flappymini;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

import java.util.Random;

public class GameView extends View {

    Paint paint;
    int birdX = 300;
    int birdY = 500;
    int velocity = 0;
    int gravity = 2;

    int pipeX;
    int pipeGap = 350;
    int pipeWidth = 120;
    int pipeSpeed = 8;
    int pipeTopHeight;

    int score = 0;
    int bestScore = 0;
    boolean gameOver = false;

    Random random;
    SharedPreferences prefs;

    public GameView(Context context) {
        super(context);
        paint = new Paint();
        random = new Random();

        pipeX = 1200;
        pipeTopHeight = random.nextInt(600) + 200;

        prefs = context.getSharedPreferences("FlappyPrefs", Context.MODE_PRIVATE);
        bestScore = prefs.getInt("best", 0);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvas.drawColor(Color.CYAN);

        paint.setColor(Color.RED);
        canvas.drawCircle(birdX, birdY, 40, paint);

        paint.setColor(Color.GREEN);
        canvas.drawRect(pipeX, 0, pipeX + pipeWidth, pipeTopHeight, paint);
        canvas.drawRect(pipeX, pipeTopHeight + pipeGap,
                pipeX + pipeWidth, getHeight(), paint);

        if (!gameOver) {
            velocity += gravity;
            birdY += velocity;
            pipeX -= pipeSpeed;

            if (pipeX < -pipeWidth) {
                pipeX = getWidth();
                pipeTopHeight = random.nextInt(600) + 200;
                score++;
            }

            if (birdY > getHeight() || birdY < 0 ||
                    (birdX + 40 > pipeX && birdX - 40 < pipeX + pipeWidth &&
                            (birdY - 40 < pipeTopHeight ||
                                    birdY + 40 > pipeTopHeight + pipeGap))) {

                gameOver = true;

                if (score > bestScore) {
                    bestScore = score;
                    prefs.edit().putInt("best", bestScore).apply();
                }
            }
        }

        paint.setColor(Color.BLACK);
        paint.setTextSize(50);
        canvas.drawText("Score: " + score, 50, 80, paint);
        canvas.drawText("Best: " + bestScore, 50, 140, paint);

        if (gameOver) {
            paint.setTextSize(80);
            canvas.drawText("GAME OVER", 150, getHeight() / 2, paint);
            paint.setTextSize(50);
            canvas.drawText("Tap to Restart", 220, getHeight() / 2 + 80, paint);
        }

        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            if (!gameOver) {
                velocity = -25;
            } else {
                restartGame();
            }
        }
        return true;
    }

    private void restartGame() {
        birdY = 500;
        velocity = 0;
        pipeX = getWidth();
        score = 0;
        gameOver = false;
    }
}
