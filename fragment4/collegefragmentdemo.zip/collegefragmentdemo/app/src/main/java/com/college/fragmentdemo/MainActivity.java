package com.college.threefragmentapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity
        implements InputFragment.OnSendDataListener {

    OutputFragment outputFragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Load Input Fragment
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.input_container, new InputFragment())
                .commit();

        // Load Output Fragment
        outputFragment = new OutputFragment();
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.output_container, outputFragment)
                .commit();
    }

    @Override
    public void sendData(String text1, String text2) {
        outputFragment.displayText(text1, text2);
    }
}
