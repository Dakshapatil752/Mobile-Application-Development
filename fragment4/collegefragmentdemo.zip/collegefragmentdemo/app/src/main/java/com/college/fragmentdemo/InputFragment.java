package com.college.fragmentdemo;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.fragment.app.Fragment;

public class InputFragment extends Fragment {

    EditText etOne, etTwo;
    Button btnSend;
    OnSendDataListener listener;

    public interface OnSendDataListener {
        void sendData(String text1, String text2);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        listener = (OnSendDataListener) context;
    }

    @Override
    public View onCreateView(LayoutInflater inflater,
                             ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_input, container, false);

        etOne = view.findViewById(R.id.etOne);
        etTwo = view.findViewById(R.id.etTwo);
        btnSend = view.findViewById(R.id.btnSend);

        btnSend.setOnClickListener(v -> {
            listener.sendData(
                    etOne.getText().toString(),
                    etTwo.getText().toString()
            );
        });

        return view;
    }
}
